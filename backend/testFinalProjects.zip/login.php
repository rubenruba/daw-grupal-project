<?php
    include './variables.php';

    $loginEmail = trim($_REQUEST['email']);
    $loginPassword = trim($_REQUEST['password']);

    try {
        $db = new PDO("mysql:host=$serverName;dbname=$database", $user, $password);

        $dbQuery = $db->query("SELECT * FROM `User` WHERE `Email` = '$loginEmail'");
        $row = $dbQuery->fetchAll();

        checkPassword($row[0], $loginEmail, $loginPassword);

    } catch (PDOException $e){
        echo $e;
    }

    // Comprueba que hay usuario y que coincide la contraseña
    function checkPassword($user, $loginEm, $loginPass){
        if($loginEm === $user['Email']){
            if(password_verify($loginPass, $user['Password'])){
                echo "La contraseña coincide, iniciando sesión...";
            } else {
                echo "Contraseña incorrecta";
            }
        } else {
            echo "No existe un usuario con ese correo";
        }
    }
?>