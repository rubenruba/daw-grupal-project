<?php
    include '../variables.php';

    $nameNav = $_POST['name'];
    $surnameNav = $_POST['surname'];
    $passwordNav = $_POST['password'];
    $gmailNav = $_POST['email'];
    $usernameNav = $_POST['username'];
    $pswdHash = password_hash($passwordNav, PASSWORD_BCRYPT);

    $db = new PDO("mysql:host=$serverName;dbname=$database", $user, $password);

    $dbQuery ="INSERT INTO `User`(`Name`, `Surname`, `Email`, `Password`, `Username`, `Admin`)
            VALUES('$nameNav', '$usernameNav', '$gmailNav', '$pswdHash', '$usernameNav', '0');";

    try {
        $db->query($dbQuery);

        echo "Usuario creado correctamente";

        $db = null;
        $dbQuery = null;

    } catch (PDOException $e) {
        echo "Error al añadir usuario: ".$e;
        die();
    }
?>