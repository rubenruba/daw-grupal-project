<?php
    include '../variables.php';

    $text = $_POST['postText'];
    $files = $_POST['files'];

    $db = new PDO("mysql:host=$serverName;dbname=$database", $user, $password);

    $dbQuery = "INSERT INTO `Post`(`UserId`, `Text`, `Date`)
            VALUES('$nameNav', '$text', 'CURRENT_TIMESTMAP()');";

    try {
        $db->query($dbQuery);

        echo "Usuario creado correctamente";

        $db = null;
        $dbQuery = null;

    } catch (PDOException $e) {
        echo "Error al añadir usuario: ".$e;
        die();
    }
?>