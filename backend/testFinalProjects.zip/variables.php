<?php
    $serverName = 'localhost'; // Cambiar al nombre de la máquina cuando se haga el despliegue
    $database = 'aplication';
    $user = 'admin';
    $password = '_!q*6@8aPBqUN(5P';
?>