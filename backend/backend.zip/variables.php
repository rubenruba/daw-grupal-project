<?php
    $serverName = 'aplication.ctckcqouk343.us-east-1.rds.amazonaws.com'; // Cambiar al nombre de la máquina cuando se haga el despliegue
    $database = 'aplication';
    $user = 'admin';
    $password = '12345.aa';
?>
